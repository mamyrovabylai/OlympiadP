<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
if(isset($_SESSION["studentLogin"])&& isset($_SESSION["studentPassword"])){
	if(loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
		header('Location: http://z70728st.beget.tech/student');
		exit();
	}
} else if(isset($_SESSION["teacherLogin"])&& isset($_SESSION["teacherPassword"])){
	if(loginT($_SESSION["teacherLogin"],$_SESSION["teacherPassword"])){
		header('Location: http://z70728st.beget.tech/teacher');
		exit();
	}
}
	?>
<html>
<head>
<title>Distance olympiads</title>
<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="css/main.css">
</head>

<body>
<?php
include("header.html");
?>

	<div class="blocks" id="firstContent">
		<div class="content" id="content1">
		<div class="content1">
		<img id="medal" src="1.png">
		<div id="content1text">
		<center><label id="content1title">Олимпиада для учеников</label></br></br>
		<div id="c1text"><label>Благодаря олимпиадам у каждого ученика имеется возможность заявить о своих навыках в области олимпиад. Участвуйте, получайте бесценный опыт, заимайте места!</label></div></center>
		</div>
		</div>
		</div>
	</div>
	
	<div class="blocks"  id="secondContent">
		<div class="content">
			<center><div class="content2">
				<div id="c2title">
					<label>Возможности для учителей</label>
				</div>
				</br>
				</br>
				<div id="c2text">
					<p>Lorem ipsum dolor sit amet. Natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam. Ratione voluptatem sequi nesciunt, neque porro quisquam est. Maiores alias consequatur aut odit. Culpa, qui est, qui in culpa, qui blanditiis praesentium voluptatum. Cumque nihil impedit, quo voluptas assumenda est omnis. </p>
					<p>Sunt in ea commodi autem vel illum, qui dolorem eum fugiat. Nemo enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam. Nam libero tempore, cum soluta. Dolorem eum fugiat, quo minus id quod. Placeat, facere possimus, omnis voluptas assumenda est. </p>
				</div>
				<img src="2.png">
				</center>
			</div>
		</div>
	</div>
	
	<div class="blocks" id="thirdContent">
		<div class="content">
			<div class="content3">
				<div id="img">
					<center><img src="3.png"></center>
				</div>
				<div id="c3text">
					<div>
					<label id="c3title">Islam Shintemirov</label>
					</div>
					<div>
						<p>School: Nazarbayev Intellectual School </p>
						<p>Lorem ipsum dolor sit amet. Obcaecati cupiditate non numquam eius modi tempora incidunt, ut et quas molestias. Nisi ut labore et expedita. Consequatur aut perferendis doloribus asperiores. Saepe eveniet, ut enim ad minima veniam. Dignissimos ducimus, qui blanditiis praesentium voluptatum deleniti atque corrupti quos. Consequuntur magni dolores eos, qui dolorem eum fugiat, quo voluptas. Alias consequatur aut odit aut odit aut officiis debitis aut officiis debitis. </p>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<div class="blocks" id="fourthContent">
		<div class="content">
		
		</div>
	</div>
<?php
include("footer.html");
?>
</body>
</html>