<?php
	session_start();
	require_once("functions.php");
	
	
	if(isset($_POST["loginButton"])){
		$login=trim(stripslashes(htmlspecialchars($_POST["login"])));
		$password=trim(stripslashes(htmlspecialchars($_POST["password"])));
		if((!checkString($login))||(!checkString($password))){
			echo '<script type="text/javascript"> window.location=\'http://z70728st.beget.tech/studentLogin.php?q=2\'</script>';
			exit();
		}
		
		if(empty($login) || empty($password)) {header('Location: http://z70728st.beget.tech/studentLogin.php?q=1');} 
		else {
			if(loginS($login,md5($password))){
				header('Location: student/index.php');
				$_SESSION["studentLogin"]=$login;
				$_SESSION["studentPassword"]=md5($password);
				
				exit();
			} else{
				header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
			
				exit();
			}
		}
	}
	?>