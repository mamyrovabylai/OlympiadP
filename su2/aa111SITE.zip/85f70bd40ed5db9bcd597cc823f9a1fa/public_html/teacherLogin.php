<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
if(isset($_SESSION["studentLogin"])&& isset($_SESSION["studentPassword"])){
	if(loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
		header('Location: http://z70728st.beget.tech/student');
		exit();
	}
} else if(isset($_SESSION["teacherLogin"])&& isset($_SESSION["teacherPassword"])){
	if(loginT($_SESSION["teacherLogin"],$_SESSION["teacherPassword"])){
		header('Location: http://z70728st.beget.tech/teacher');
		exit();
	}
}
	?>
<html>
<head>
	<title>
	Вход
	</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" type="text/css" href="css/loginMain.css"/>
</head>

<body>
	<div class="header">
		<div id="firstHeadElem">
		<a href="index.php">OlympiadP</a>
		</div>
	</div>
	<div class="underHead">
	
	</div>
<div class="form">
	<div class="formHead">
		Вход Учителя
		<hr/>
	</div>
	<div class="formMain" >
	<form action="checkLoginTeacher.php" method="POST">
	<input type="text" name="login" placeholder="Login" size="45%"/><br/>
	<input type="password" name="password" placeholder="Password" size="45%"/>
	<br/> <br/>
	<input type="submit" name="loginButton" value="Войти" id="button"/>
	<a href=""> Забыли пароль?</a>
	</form>
	<?php
	if($_GET["q"]=="0") echo "<i style=\"color:#c80000;\">Неправильный пароль или логин!</i>";
	else if($_GET["q"]=="1") echo "<i style=\"color:#c80000;\">Укажите все данные входа!</i>";
	else if($_GET["q"]=="2") echo "<i style=\"color:#c80000;\">Запрещаются пробелы и знаки \" ; \" !</i>";
	?>
	</div>
	
</div>
<?php include("footer.html"); ?>
<div class="bottom">

</div>
</body>


</html>
