<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
function connect(){
		$mysqli= new mysqli(
	"localhost",
	"z70728st_zakaz",
	"4588hkE",
	"z70728st_zakaz"
	);
		if($mysqli->errno!=0){
			return false;
		} else return $mysqli;
	}
function checkString($s){
		for($i=0;$i<strlen($s);$i++){
			if( ($s[$i]==";") || ($s[$i]==" ") ){
				return false;
			}
		}
		return true;
}
$mysqli=connect();
if($mysqli!=false){
	if(isset($_POST["voiti"])){
	if(isset($_POST["login"])&&isset($_POST["password"])){
		$login=trim(stripslashes(htmlspecialchars($_POST["login"])));
		$password=trim(stripslashes(htmlspecialchars($_POST["password"])));
		if( (checkString($login)==false) || ( checkString($password)==false) ){
			echo '<script type="test/javascript">
			window.location="http://z70728st.beget.tech/admin/index.php?q=2";
			</script>';
			exit();
		}
		$password=md5($password);
		$q="SELECT `password` FROM `adminusers` WHERE `login`='$login';";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$bdpassword=$rows["password"];
		if($password==$bdpassword){
			$_SESSION["admin"]="accessed";
			echo '<script type="text/javascript">
			window.location="http://z70728st.beget.tech/admin/index12.php";
			</script>';
			exit();
		} else {
			echo '<script type="text/javascript">
			window.location="http://z70728st.beget.tech/admin/index.php?q=1";
			</script>';
			exit();
		}
	} else {
		echo "Все равно не взломаешь)";
	}
	} else echo "Не взломаешь )" ;
}
?>