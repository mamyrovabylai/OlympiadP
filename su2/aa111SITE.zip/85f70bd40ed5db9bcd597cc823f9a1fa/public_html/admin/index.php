<?php
header('Content-Type: text/html; charset= utf-8');
?>
<html>
<head>
<meta charset="utf-8"/>
<link rel="stylesheet" href="index1.css"/>
<title> Войти как админ </title>
</head>

</body>
<div>
<span> Войти как админ </span>
</div>
<form action="checkAdmin.php" method="post" >
<input type="text" placeholder="Login" name="login" required /><br/>
<input type="password" placeholder="Password" name="password"required /><br/>
<input type="submit" value="Войти" name="voiti"/>
</form>
<?php
if(isset($_GET["q"])){
	$x=$_GET["q"];
	if($x=="1"){
		echo "Неправильный логин или пароль!";
	} else if($x=="2"){
		echo "Запрещаются символы '[пробел] ' , ' ; '";
	}
}
?>
</body>
</html>