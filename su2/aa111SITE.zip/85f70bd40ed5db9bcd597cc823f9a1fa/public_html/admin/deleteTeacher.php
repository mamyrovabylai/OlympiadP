<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
if((!isset($_SESSION["admin"])) || ($_SESSION["admin"]!="accessed")){
		header('Location: http://z70728st.beget.tech/admin/index.php');
		exit();
	
}
function connect(){
	$mysqli= new mysqli(
	"localhost",
	"z70728st_zakaz",
	"4588hkE",
	"z70728st_zakaz"
	);
	if($mysqli->errno!=0){
		return false;
	} else return $mysqli;
}

function deleteTeacher($email){
	$mysqli=connect();
	if(!$mysqli){echo "Acces denied";} else{
		$q="SELECT `login` FROM `teacherusers` WHERE `email`='$email'";
		$result=$mysqli->query($q);
		if($result->num_rows==0){echo "Таких пользователей нет!<br/>" ;} else{
			$rows=$result->fetch_assoc();
			$q="DELETE FROM teacherusers WHERE email='$email';";
			$mysqli->query($q);
			echo $rows["login"]." was deleted!<br/>";
			
		}
	}
}


if(isset($_POST["deleteButton"])){
	$email=trim(stripslashes(htmlspecialchars($_POST["email"])));
		deleteTeacher($email);
}
echo "<a href=\"index12.php\"> Go to the main page </a>";
?>