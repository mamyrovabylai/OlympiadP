<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
if((!isset($_SESSION["admin"])) || ($_SESSION["admin"]!="accessed")){
		header('Location: http://z70728st.beget.tech/admin/index.php');
		exit();
	
}
function connect(){
	$mysqli= new mysqli(
	"localhost",
	"z70728st_zakaz",
	"4588hkE",
	"z70728st_zakaz"
	);
	if($mysqli->errno!=0){
		return false;
	} else return $mysqli;
}

function update($x,$y,$constemail){
	$mysqli=connect();
	if(!$mysqli){echo "Acces denied";} else{
		$q="SELECT `login` FROM `teacherusers` WHERE `email`='$constemail'";
		$result=$mysqli->query($q);
		if($result->num_rows==0){echo "����� ������������� ���!<br/>" ;}  else{
			$rows=$result->fetch_assoc();
			$q="UPDATE teacherusers SET $x='$y' WHERE email='$constemail';";
			$mysqli->query($q);
			echo $rows["login"]."'s $x was updated<br/>";
		}
	}
}






if(isset($_POST["updateButton"])){
	$constemail=trim(stripslashes(htmlspecialchars($_POST["email"])));
	if(isset($_POST["loginCheck"])){
		$login=trim(stripslashes(htmlspecialchars($_POST["newLogin"])));
		if(empty($login)){ echo " Password ���� �� ���������!";} else {
		update("login",$login,$constemail);}
	}
	if(isset($_POST["passwordCheck"])){
		$password=trim(stripslashes(htmlspecialchars($_POST["newPassword"])));
		$p=trim(stripslashes(htmlspecialchars($_POST["newPasswordAgain"])));
		if($password==$p){
			if(empty($password)){ echo "Password ���� �� ���������!";} else {
			update("passwords",md5($password),$constemail);}
		} else{echo "p!=password";}
		
	}
	if(isset($_POST["subjectCheck"])){
		$subject=trim(stripslashes(htmlspecialchars($_POST["newSubject"])));
		if(empty($subject)){ echo "Subject ���� �� ���������!";} else {
		update("subject",$subject,$constemail);}
	}
	if(isset($_POST["emailCheck"])){
		$email=trim(stripslashes(htmlspecialchars($_POST["newEmail"])));
		if(empty($email)){ echo "E-mail ���� �� ���������!";} else {
		update("email",$email,$constemail);
		}
	}
	if(isset($_POST["schoolCheck"])){
		$school=trim(stripslashes(htmlspecialchars($_POST["newSchool"])));
		if(empty($school)){ echo "E-mail ���� �� ���������!";} else {
		update("school",$school,$constemail);
		}
	}
}
echo "<br/><a href=\"index12.php?q=2\"> Go to the back </a>";

?>