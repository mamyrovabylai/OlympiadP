<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["studentLogin"]) || !isset($_SESSION["studentPassword"]) ){
	header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
} else if(!loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
	 header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["studentLogin"];
	$password=$_SESSION["studentPassword"]; 
}
if(isset($_POST["changePassword"])){
	if(isset($_POST["password"])&&isset($_POST["passwordNew"])&&isset($_POST["passwordAgain"])){
		$pass=$_POST["password"];
		$newp=$_POST["passwordNew"];
		$againp=$_POST["passwordAgain"];
		if(loginS($login,md5($pass))){
			if($newp==$againp){
				$newp=md5($newp);
				$mysqli=connect();
				$q="UPDATE `studentusers` SET `passwords`='$newp' WHERE `login`='$login';";
				$result=$mysqli->query($q);
				header('Location: http://z70728st.beget.tech/studentLogin.php');
				exit();
			} else { 
					header('Location: http://z70728st.beget.tech/student/profile.php?q=1');
					exit();
			}
		}else {header('Location: http://z70728st.beget.tech/student/profile.php?q=2');
					exit();}
	} else {	header('Location: http://z70728st.beget.tech/student/profile.php?q=3');
					exit();}
} else { header('Location: http://z70728st.beget.tech/student/profile.php');
					exit();}
?>