<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["studentLogin"]) || !isset($_SESSION["studentPassword"]) ){
	header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
} else if(!loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
	 header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["studentLogin"];
	$password=$_SESSION["studentPassword"]; 
}

?>
<html>
<head>
<style>
.main a{
	color:#FFF;
	text-decoration:underline;
}
.main button a{
	color:black;
	text-decoration:none;
}
</style>
<title> Олимпиада</title>
<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/inform.css" type="text/css"/>
</head>

<body>
<?php include("header.html"); ?>
<div class="main">
<?php 
		$id=trim(stripslashes(htmlspecialchars($_GET["q"])));
	   require_once("functions.php");
		$mysqli=connect();
		$now=date("Y-m-d H:i:s");
		if ($mysqli){
			$q="SELECT `name`,`subject`,`teacher`,`time_start`,`time_end`,`description` FROM `olympiads` WHERE `id`='".$id."';";
			$result=$mysqli->query($q);
			if($result->num_rows==1){
			$rows=$result->fetch_assoc();
			echo "Название олимпиады : ".$rows["name"]."<br/><br/>";
			echo "Предмет : ".$rows["subject"]."<br/><br/>";
			echo "Создатель олимпиады : ".$rows["teacher"]."<br/><br/>";
			echo "Про олимпиаду : ".$rows["description"]."<br/><br/>";
			echo "Начало : ".date('H:i j F',strtotime($rows["time_start"]))."<br/><br/>";
			echo "Завершение : ".date('H:i j F',strtotime($rows["time_end"]))."<br/><br/>";
			if($now>$rows["time_end"]){/*
				$slogin=$rows["first_place"];
				$q="SELECT `name` FROM `studentusers` WHERE `login`='$slogin';";
				$result=$mysqli->query($q);
				$rows1=$result->fetch_assoc();
				$sname=$rows1["name"];
			echo "Золото занял(и) : <a href=\"studentRate.php?q=".$slogin."\">".$sname." </a> <br/><br/>";
			$slogin=$rows["second_place"];
				$q="SELECT `name` FROM `studentusers` WHERE `login`='$slogin'";
				$result=$mysqli->query($q);
				$rows1=$result->fetch_assoc();
				$sname=$rows1["name"];
			echo "Серебро занял(и) : <a href=\"studentRate.php?q=".$slogin."\">".$sname." </a> <br/><br/>";
			$slogin=$rows["third_place"];
				$q="SELECT `name` FROM `studentusers` WHERE `login`='$slogin'";
				$result=$mysqli->query($q);
				$rows1=$result->fetch_assoc();
				$sname=$rows1["name"];
			echo "Бронзу занял(и) : <a href=\"studentRate.php?q=".$slogin."\">".$sname." </a> <br/><br/>";*/
			echo "<a href=\"aboutOlympiadPassers.php?q=$id\" style=\"color:#fff;\">Результаты</a>";
			} else if($now<$rows["time_start"]) {
				
				echo '<form action="addOlympiad.php" method="POST">
				<button type="submit" name="addOlympiadButton" value="'.$id.'"> Принять участие в олимпиаде</button>
				</form>';
				switch($_GET["a"]){
						case "1":
							 echo "Вы успешно добавили в список ваших олимпиад!";
							break;
						case "2":
							echo "Отказано!";
							break;
						case "3":
							echo "Нельзя записаться из за времени!";
							break;
						case "4":
							echo "Вы уже записаны!";
							break;
				}
			}
			} else { echo "Такой олимпиады нет!";}
		}
	?>
<button style="float:right;" id="link"><a id="link" href="index.php" >Назад</a></button><br/>
</div><br/>
<?php
include("footer.html");
?>
<br/>
</body>

</html>