<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["studentLogin"]) || !isset($_SESSION["studentPassword"]) ){
	header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
} else if(!loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
	 header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["studentLogin"];
	$password=$_SESSION["studentPassword"]; 
}

?>
<html>
<head>
	<title> Rating</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/rating.css" type="text/css"/>
</head>

<body>
		<?php
		include("header.html");
		include("underhead.php");
		echo "<div class=\"main\">";
	    $names=array();
		$logins=array();
		$ratings=array();
		$scores=array();
		$mysqli=connect();
		if ($mysqli){
			
			
			if(!isset($_POST["searchStudent"]) || !isset($_POST["searchStudentButton"]) ){
			$q="SELECT `name`,`login` FROM `studentusers`";
			} else {$q="SELECT `name`,`login` FROM `studentusers` WHERE `name` LIKE '%".$_POST["searchStudent"]."%';";}
			
			
			$result=$mysqli->query($q);
			echo '<form method="POST" class="ratingForm"> <input type="text" class="ratingFormEdit" name="searchStudent" size="45%" placeholder="Введите имя ученика"/> <input class="ratingFormButton" type="submit" name="searchStudentButton" value="Поиск"/> </form>';
			//выборка данных score ,login,name
			if($result->num_rows==0){ echo "<span>Таких учеников нет!</span>";} else{
				
				
				$rows=$result->fetch_assoc();
				$q2="SELECT `score` FROM `studentolympiads` WHERE `login`='$login';";
				$result2=$mysqli->query($q2);
			$rows2=$result2->fetch_assoc();
			$i=0;
			do{
				$login=$rows["login"];
				$name=$rows["name"];
				
			$q2="SELECT `score` FROM `studentolympiads` WHERE `login`='$login';";
			$result2=$mysqli->query($q2);
			$rows2=$result2->fetch_assoc();
			$score=$rows2["score"];
			
			$logins[$i]=$login;
			$names[$i]=$name;
			$scores[$i]=$score;
			$i++;
				
			} while($rows=$result->fetch_assoc());
			
			
			
			
			//сортировка
			for($j=0;$j<$i;$j++){
				for($g=$j+1; $g<$i+1; $g++){
					if($scores[$g]>$scores[$j]){
						$buff=$scores[$g];
						$scores[$g]=$scores[$j];
						$scores[$j]=$buff;
						
						$buff=$logins[$g];
						$logins[$g]=$logins[$j];
						$logins[$j]=$buff;
						
						$buff=$names[$g];
						$names[$g]=$names[$j];
						$names[$j]=$buff;
					}
				}
			}
			
			//вывод
			echo "<ol class=\"list\" />";
			for($j=0;$j<$i;$j++){
				echo "<li class=\"listElem\"><a href=\"studentRate.php?q=".$logins[$j]."\">".$names[$j]." </a></li> <br/><br/> " ;
			}
			echo "</ol>";
		}
		
		}
		
		echo "</div>";	
		include("footer.html");
		?>
</body>
			<div class="bottom">

			</div>
</html>