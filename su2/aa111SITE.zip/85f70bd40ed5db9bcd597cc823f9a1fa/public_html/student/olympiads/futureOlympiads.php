<form method="POST" class="formSelect"/>
<select name="subject" size="1">
<option disabled selected>Выберите предмет </option>
<option value="География">География</option>
<option value="Право">Право</option>
<option value="Информатика">Информатика</option>
<option value="История">История Казахстана</option>
</select>
<input type="submit" class="buttonSelect" value="Выбрать" name="button"/>
</form>
<?php
$mysqli=connect();
$now=date("Y-m-d H:i:s");
if(isset($_POST["subject"]) && isset($_POST["button"]) ){
	$subject=$_POST["subject"];
	$q="SELECT `name`,`id` FROM `olympiads` WHERE `time_start`>'$now' AND `subject`='$subject';";
	}else {
	$q="SELECT `name`,`id` FROM `olympiads` WHERE `time_start`>'$now';"; 
	}
$result=$mysqli->query($q);
if($result->num_rows==0){ echo "<span>Таких олимпиад нет!</span>";} else{
$rows=$result->fetch_assoc();

 echo "<ul class=\"list\" />";
do{
	
				$elem=$rows["name"];
					$elemid=$rows["id"];
				
					echo "<li class=\"listElem\"> <a href=\"aboutOlympiad.php?q=".$elemid."\"> $elem </a></li><br/>";
					
					
				
}while ($rows=$result->fetch_assoc());
echo "</ul>";
}
?>