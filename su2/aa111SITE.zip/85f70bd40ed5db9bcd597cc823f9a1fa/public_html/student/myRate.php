<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["studentLogin"]) || !isset($_SESSION["studentPassword"]) ){
	header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
} else if(!loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
	 header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["studentLogin"];
	$password=$_SESSION["studentPassword"]; 
}

?>
<html>

<head>
	<title> Мои достижения</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/inform.css" type="text/css"/>
</head>
<style>
table{
border-collapse:collapse;	
}
td{
	color:#fff;
	padding:5px;
}
table,tr,td{
	border:1px solid silver;
}
</style>
<body>
<?php include("header.html"); ?>
<div class="main">
<?php
$mysqli=connect();
$q="SELECT `score`,`your_olympiads`,`olympiad_bands`,`your_bands`,`olympiad_passed` FROM `studentolympiads` WHERE `login`='$login';";
$result=$mysqli->query($q);
$rows=$result->fetch_assoc();
$places=array(); $places=explode(";",$rows["places"]);

$score=$rows["score"];
$your_olympiads=array(); $your_olympiads=explode(";",$rows["your_olympiads"]);
$your_bands=array(); $your_bands=explode(";",$rows["your_bands"]);
$olympiad_passed=array(); $olympiad_passed=explode(";",$rows["olympiad_passed"]);
$olympiad_bands=array(); $olympiad_bands=explode(";",$rows["olympiad_bands"]);
$count=count($olympiad_passed)-1;
echo "Мой общий балл- $score<br/><br/>";
echo "<table class=\"table\" cols=\"3\"  >";
echo "<tr> 
<td>Название олимпиады</td>
<td>Кол-во набранных/всего баллов</td>
<td>Ссылка на результаты олимпиад</td>
</tr>
";
for($i=$count;$i>-1;$i--){
	if($olympiad_passed[$i]=="1"){
		$id=$your_olympiads[$i];
		$band=$your_bands[$i];
		$total_band=$olympiad_bands[$i];
		$q="SELECT `name` FROM `olympiads` WHERE `id`='$id'";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$name=$rows["name"];
		echo "<tr>";
		echo "<td>  <a href=\"aboutOlympiad.php?q=".$id."\" style=\"color:#FFF; text-decoration:underline;\"> $name </a>    </td>";
		echo "<td> <span style=\"color:#fff;\"> $band / $total_band </span></td>";
		echo "<td> <a href=\"aboutOlympiadPassers.php?q=$id\" style=\"color:#fff; text-decoration:underline;\">Результаты  $name</a>  </td>";
		echo "</tr>";
	}
		
	}
	echo "</table>";

?>
<button style="float:right;margin-top:3%;" id="link"><a  href="profile.php" >Назад</a></button><br/>
</div><br/>
<?php
include("footer.html");
?>