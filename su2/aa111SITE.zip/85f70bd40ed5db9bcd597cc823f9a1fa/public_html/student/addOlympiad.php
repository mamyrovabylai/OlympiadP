<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["studentLogin"]) || !isset($_SESSION["studentPassword"]) ){
	header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
} else if(!loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
	 header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["studentLogin"];
	$password=$_SESSION["studentPassword"]; 
}

?>
<html>
<head>
<title>
Add olympiad
</title>
<meta charset="utf-8"/>
</head>
<body>
<?php
require_once("functions.php");
if(isset($_POST["addOlympiadButton"])) {
	$x=$_POST["addOlympiadButton"];
	$mysqli=connect();
	$id=$_POST["addOlympiadButton"];
	$q="SELECT `name`,`time_start` FROM `olympiads` WHERE `id`='$id';";
	$result=$mysqli->query($q);
	$rows=$result->fetch_assoc();
	$ol=$rows["name"];
	$time=$rows["time_start"];
	$var=strtotime($time);
	$var1=time();
	if($var1<$var){
	
		$q="SELECT `your_olympiads`,`your_bands`,`olympiad_bands`,`olympiad_passed` FROM `studentolympiads` WHERE `login`='$login'";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$yourol=$rows["your_olympiads"];
		$yourban=$rows["your_bands"];
		$olympbands=$rows["olympiad_bands"];
		$yourpass=$rows["olympiad_passed"];
		$mass=explode(";",$yourol);
		$mass2=explode(";",$yourban);
		$bool=true;
		$q="SELECT `total_band` FROM `olympiads` WHERE `id`=$id";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$olband=$rows["total_band"];
		
		foreach($mass as $elem){
			if($elem==$id){
				$bool=false;
				break;
			}
		}
		
		
	if($bool){
		$ool=$yourol.$id.";";
		$band=$yourban."-1;";
		$olbands=$olympbands.$olband.";";
		$passed=$yourpass."0;";
		$q="UPDATE `studentolympiads` SET `your_olympiads`='$ool' , `your_bands`='$band' , `olympiad_bands`='$olbands', `olympiad_passed`='$passed' WHERE `login`='$login';";
		$result=$mysqli->query($q);
		
		$q="SELECT `participants`,`bands` FROM `olympiads` WHERE `id`='$id';";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$participants=$rows["participants"].$login.";";
		$bbbands=$rows["bands"]."-1;";
		$q="UPDATE `olympiads` SET `participants`='$participants',`bands`='$bbbands' WHERE `id`='$id';";
		$result2=$mysqli->query($q);
	if($result->errno==0 && $result2->errno==0){
		echo "<script type=\"text/javascript\" >window.location=\"http://z70728st.beget.tech/student\"; </script>";
	} else {
		echo "<script type=\"text/javascript\" >window.location=\"aboutOlympiad.php?q=$x&a=2\"; </script>";
	}
	} else {echo "<script type=\"text/javascript\" >window.location=\"aboutOlympiad.php?q=$x&a=4\"; </script>" ;}
} else { echo "<script type=\"text/javascript\" >window.location=\"aboutOlympiad.php?q=$x&a=3\"; </script>";}
}
?>
</body>
</html>