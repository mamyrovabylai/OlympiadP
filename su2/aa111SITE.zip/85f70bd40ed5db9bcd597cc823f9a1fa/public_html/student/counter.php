<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["studentLogin"]) || !isset($_SESSION["studentPassword"]) ){
	header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
} else if(!loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
	 header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["studentLogin"];
	$password=$_SESSION["studentPassword"]; 
}

?>
<html>
<head>
	<title> Показатель</title>
	<link rel="stylesheet" type="text/css" href="css/olympiad.css"/>
</head>
<style>
.main{
	margin-top:15%;
}
	
	button{
		background-color:#d8d8d8;
		float:right;
		margin-top:0%;
		height:5%;
	}
	a{
		text-decoration:none;
	}
</style>
</body>
<div class="main">
<?php
if(isset($_GET["x"]) && isset($_GET["y"])){
	$x=$_GET["x"];
	$obw=$_GET["y"];
	echo "Поздравляем! <br/> <br/>Вы получили $obw баллов из $x.";
	
}
?>
<button>
	<a href="http://z70728st.beget.tech/student"> Назад </a>
</button>
</div>
</body>
</html>