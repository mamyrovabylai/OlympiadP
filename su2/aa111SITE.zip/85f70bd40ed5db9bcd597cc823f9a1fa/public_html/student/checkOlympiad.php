<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
$login=$_SESSION["studentLogin"];
if(isset($_POST["id"])){
$id=$_POST["id"]; // id олимпиады
$keys=array();
$values=array();
$count=0;
foreach($_POST as $key => $value){
	$keys[$count]=$key;
	$values[$count]=$value;
	$count++;
}// post запросы по keys и values

$mysqli= new mysqli(
	"localhost",
	"z70728st_zakaz",
	"4588hkE",
	"z70728st_zakaz"
	);// подключение к БД
	
	$mcp=array();
	for($i=0;$i<$count;$i++){
		$key=$keys[$i];
		$type=$key[0].$key[1];
		if($type=="mc"){
			$identi=stristr($key,$key[2]);
			$identi=(int)$identi;
			$mcp["$identi"]=0;
		}
	}// mcp - это массив для количесвто правильных ответов из multiple choice , идентифицируемая по identi mc-вопроса
	$mcr=array();
	$obw=0;
	$k=0;
for($i=0;$i<$count;$i++){
	$key=$keys[$i];
	$value=$values[$i];
	$type=$key[0].$key[1];
	
	if($type=="mc"){
		$identi=stristr($key,$key[2]);
		$identi=(int)$identi;
		$q="SELECT `right_answers` FROM `olympiad$id` WHERE `type`='$type' AND `identi`='$identi';";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$x=$rows["right_answers"];
		$rans=array();
		$rans=explode(";",$x);
		$count2=count($rans)-1;
		$bool=false;
		$mcr["$identi"]=$count2;
		for($j=0;$j<$count2;$j++) {
			if ( $rans[$j]==$value) {
				$mcp["$identi"]+=1;
				break;
			}
		}
		$q="SELECT `point` FROM `olympiad$id` WHERE `type`='$type' AND `identi`='$identi';";
			$result=$mysqli->query($q);
			$rows=$result->fetch_assoc();
		if($mcp["$identi"]==$mcr["$identi"]) {
			$obw+=(int)$rows["point"];
		} else if ($keys[$i+1][0]!="m") { $obw+=round((((int)$rows["point"])/((int)$mcr["$identi"]))*((int)$mcp["$identi"]),1) ;}
		
		
	} else if ($type=="sc"){
		$identi=stristr($key,$key[2]);
		$q="SELECT `right_answers` FROM `olympiad$id` WHERE `type`='$type' AND `identi`='$identi';";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$rans=$rows["right_answers"];
		if($rans==$value) {
			$q="SELECT `point` FROM `olympiad$id` WHERE `type`='$type' AND `identi`='$identi';";
			$result=$mysqli->query($q);
			$rows=$result->fetch_assoc();
			$obw+=(int)$rows["point"];
		}
		
	} else if ($type=="sa"){
		$identi=stristr($key,$key[2]);
		$q="SELECT `right_answers` FROM `olympiad$id` WHERE `type`='$type' AND `identi`='$identi';";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$x=$rows["right_answers"];
		$rans=array();
		$rans=explode(";",$x);
		$count2=count($rans)-1;
		$bool=false;
		for($j=0;$j<$count2;$j++) {
			if ( $rans[$j]==$value) {
				$bool=true;
				break;
			}
		}
		if($bool) {
			
			$q="SELECT `point` FROM `olympiad$id` WHERE `type`='$type' AND `identi`='$identi';";
			$result=$mysqli->query($q);
			$rows=$result->fetch_assoc();
			$obw+=(int)$rows["point"];
		}
	}	
	}
	$x=0;
	$q="SELECT `your_olympiads`,`olympiad_bands`,`your_bands`,`score`,`olympiad_passed` FROM `studentolympiads` WHERE `login`='$login';";
	$result=$mysqli->query($q);
	$rows=$result->fetch_assoc();
	$scorebd=$rows["score"];
	$olympiad_passed=array(); $olympiad_passed=explode(";",$rows["olympiad_passed"]);
	$your_olympiads=array(); $your_olympiads=explode(";",$rows["your_olympiads"]); $count=count($your_olympiads)-1;
	$olympiad_bands=array(); $olympiad_bands=explode(";",$rows["olympiad_bands"]); 
	$your_bands=array();     $your_bands=explode(";",$rows["your_bands"]);         
	for($i=0;$i<$count;$i++){
		if($your_olympiads[$i]==$id){
			$your_bands[$i]=$obw;
			$olympiad_passed[$i]="1";
			$score=$obw/((int)$olympiad_bands[$i]);
			$score+=$scorebd;
			$x=$olympiad_bands[$i];
			break;
		}
	}
	$s="";
	$s2="";
	for($i=0;$i<$count;$i++){
		$s.=$your_bands[$i].";";
		$s2.=$olympiad_passed[$i].";";
	}
	$q="UPDATE `studentolympiads` SET `your_bands`='$s',`score`=$score,`olympiad_passed`='$s2' WHERE `login`='$login';";
	$result=$mysqli->query($q);
	
	$q="SELECT `participants`,`bands` FROM `olympiads` WHERE `id`=$id;";
	$result=$mysqli->query($q);
	$rows=$result->fetch_assoc();
	$participants=array(); $participants=explode(";",$rows["participants"]);
	$bands=array();   	   $bands=explode(";",$rows["bands"]);
	$count=count($bands)-1;
	for($i=0;$i<$count;$i++){
		if($participants[$i]==$login){
			$bands[$i]="$obw";
			break;
		}
	}
	$s="";
	for($i=0;$i<$count;$i++){
		$s.=$bands[$i].";";
	}
	$q="UPDATE `olympiads` SET `bands`='$s' WHERE `id`=$id;";
	$result=$mysqli->query($q);
	echo "<script type=\"text/javascript\"> window.location=\"http://z70728st.beget.tech/student/counter.php?x=$x&y=$obw\"; </script>";
	echo "Поздравляем вы получили $obw баллов из $x";
}
?>