<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["studentLogin"]) || !isset($_SESSION["studentPassword"]) ){
	header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
} else if(!loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
	 header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["studentLogin"];
	$password=$_SESSION["studentPassword"]; 
}

?>
<html>
</head>
<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="css/olympiad.css"/>
<title> Олимпиада</title>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>

</head>
<body>
<div class="main">
<form action="checkOlympiad.php" method="post">
<?php
if(isset($_POST["id"])){
	$id=$_POST["id"];
	$mysqli=connect();
	$boo=false;
$q="SELECT `olympiad_passed`,`your_olympiads` FROM `studentolympiads` WHERE `login`='$login';";	
$result=$mysqli->query($q);
$rows=$result->fetch_assoc();
$your_olympiads=array(); $your_olympiads=explode(";",$rows["your_olympiads"]);
$olympiad_passde=array(); $olympiad_passed=explode(";",$rows["olympiad_passed"]);
$count=count($olympiad_passed)-1;
for($i=0;$i<$count;$i++){
	if($your_olympiads[$i]==$id){
		if($olympiad_passed[$i]=="0") $boo=true;
	}
}
if($boo) {
	$q="SELECT `name` FROM `olympiads` WHERE `id`=$id;";
	$result=$mysqli->query($q);
	$rows=$result->fetch_assoc();
	$name=$rows["name"];
	echo "Олимпиада - ".$name."<br/><br/><br/>";
	$q="SELECT `question`,`type`,`possible_answers`,`identi`,`right_answers` FROM `olympiad$id`";
	$result=$mysqli->query($q);
	$rows=$result->fetch_assoc();
	$k=0;
	do{
		$question=$rows["question"];
		$type=$rows["type"];
		$pans=$rows["possible_answers"];
		$identi=$rows["identi"];
		$rans=array();
		$rans=explode(";",$rows["right_answers"]);
		$posx=count($rans)-1;
		echo "$question <br/>";
		if($type=="mc"){
			$mci++;
			$mass=explode(";",$pans);
			$count=count($mass)-1;
			for($i=0;$i<$count;$i++){
				echo "<input type=\"checkbox\" name=\"mc".$identi."a$i\" value=\"$mass[$i]\" class=\"mcc$k\" /> $mass[$i] <br/>";
			}
			
			echo "<script type=\"text/javascript\">
$('input[class=mcc$k]').change(function(){
    if($('input[class=mcc$k]:checked').length >= $posx){
        $('input[class=mcc$k]:not(:checked)').attr('disabled', true);
    } else{
        $('input[class=mcc$k]:disabled').attr('disabled', false);
    }
});
</script>";
$k++;
			echo "<br/>";
		} else if($type=="sc"){
			$sci++;
			$mass=explode(";",$pans);
			$count=count($mass)-1;
			for($i=0;$i<$count;$i++){
				echo "<input type=\"radio\" name=\"sc$identi\" value=\"$mass[$i]\" /> $mass[$i] <br/>";
			}
			echo "<br/>";
		} else if ($type=="sa"){
			$sai++;
			echo " <input type=\"text\" name=\"sa$identi\" /> <br/><br/>";
		}
	}
	while($rows=$result->fetch_assoc());
	
	echo "<button type=\"submit\" name=\"id\" value=\"$id\"> Сдать олимпиаду</button>";
}  else { echo "Вы уже сдавали эту олимпиаду!";}
} 
 else { echo "<script type=\"text/javascript\"> window.location=\"http://z70728st.beget.tech/student\" </script>"; exit();}

?>
</form>
</div>
</body>
</html>