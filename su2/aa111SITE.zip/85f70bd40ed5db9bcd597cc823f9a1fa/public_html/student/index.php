<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["studentLogin"]) || !isset($_SESSION["studentPassword"]) ){
	header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
} else if(!loginS($_SESSION["studentLogin"],$_SESSION["studentPassword"])){
	 header('Location: http://z70728st.beget.tech/studentLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["studentLogin"];
	$password=$_SESSION["studentPassword"]; 
}

?>
<html>
<head>
<title> 
Студент
</title>
<meta charset="utf-8"/>
<link rel="stylesheet" type="text/css" href="css/main.css" />
</head>
<body>

<?php
	include("header.html");
	include("underhead.php"); 	
	include("olympUnderHead.html");
	echo "<div class=\"main\">";
			if($_GET["a"]=="1"){
				include("olympiads/old.php");
			}  else if($_GET["a"]=="0") {
				include("olympiads/futureOlympiads.php");
				
			} else {
				include("olympiads/yourOlympiads.php");
			}
	echo "</div>";	

?>
</body>
<?php include("footer.html"); ?>
<div class="bottom">

</div>
</html>