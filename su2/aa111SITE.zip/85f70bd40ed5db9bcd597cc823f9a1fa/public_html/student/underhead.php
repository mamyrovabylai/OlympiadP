<?php
session_start();
require_once("functions.php");
$mysqli=connect();
$login=$_SESSION["studentLogin"];
$q="SELECT `name` FROM `studentusers` WHERE `login`='$login';";
$result=$mysqli->query($q);
$rows=$result->fetch_assoc();
$name=$rows["name"];
echo '
<div class="underHead">
			<div class="underHeadElem" id="firstUnderHeadElem">
			<a href="index.php">Олимпиады</a>
			</div>
			<div class="underHeadElem" id="secondUnderHeadElem">
			<a href="rating.php">Рейтинг</a>
			</div>
			<div class="underHeadElem" id="fourthUnderHeadElem">
			<a href="profile.php">'.$name.'</a>
			</div>
		</div>'
		?>