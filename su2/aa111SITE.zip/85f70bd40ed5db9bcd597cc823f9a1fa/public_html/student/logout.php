<?php
		session_start();
		header('Location: http://z70728st.beget.tech/index.php');
		unset($_SESSION["studentLogin"]);
		unset($_SESSION["studentPassword"]);
		exit();
?>