<?php
		session_start();
		header('Location: http://z70728st.beget.tech/index.php');
		unset($_SESSION["teacherLogin"]);
		unset($_SESSION["teacherPassword"]);
		exit();
?>