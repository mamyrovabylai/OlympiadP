<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["teacherLogin"]) || !isset($_SESSION["teacherPassword"]) ){
	header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
} else if(!loginT($_SESSION["teacherLogin"],$_SESSION["teacherPassword"])){
	 header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["teacherLogin"];
	$password=$_SESSION["teacherPassword"]; 
}

?>
<html>

<head>
	<title> Мои достижения</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/inform.css" type="text/css"/>
	<style>
	table{
border-collapse:collapse;	
}
td{
	color:#fff;
	padding:5px;
}
table,tr,td{
	border:1px solid silver;
}
</style>
</head>
<body>
<div class="main">
<?php
echo "Мои олимпиады:<br/>";
$mysqli=connect();
$q="SELECT `olympiads` FROM `teacherusers` WHERE `login`='$login';";
$result=$mysqli->query($q);
$rows=$result->fetch_assoc();
$teacherName=$rows["name"];
$teacherOlympiads=explode(";",$rows["olympiads"]);
$numberOlympiads=count($teacherOlympiads)-1;
for($i=0;$i<$numberOlympiads;$i++){
	$q="SELECT `name`,`total_band`,`participants`,`bands` FROM `olympiads` WHERE id=$teacherOlympiads[$i];";
	$result=$mysqli->query($q);
	$rows=$result->fetch_assoc();
	$olympName=$rows["name"];
	$olympBand=$rows["total_band"];
	$participants=explode(";",$rows["participants"]);
	$bands=explode(";",$rows["bands"]);
	echo "<details>
	<summary>$olympName </summary>";
	echo "<table cols=\"2\">
	<tr> <td>Участник </td> <td> Количество баллов</td> </tr>";
	$count=count($participants)-1;
	for($j=$count-1;$j>=0;$j--){
		if($bands[$j]!="-1"){
			echo "<tr><td>$participants[$j]</td> <td>$bands[$j] / $olympBand </td></tr>";
		}
	}
	echo "</table>";
	echo "</details><br/>";
}

?>
</div>

</body>

</html>