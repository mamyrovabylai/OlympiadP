<?php
function connect(){
		$mysqli= new mysqli(
	"localhost",
	"z70728st_zakaz",
	"4588hkE",
	"z70728st_zakaz"
	);
		if($mysqli->errno!=0){
			return false;
		} else return $mysqli;
	}
	function loginT($login,$password){
		$mysqli=connect();
		if(!$mysqli){ return false;} 
		else{
			$q="SELECT `passwords` FROM `teacherusers` WHERE `login`='$login';";
			$result=$mysqli->query($q);
			$rows=$result->fetch_assoc();
			if($rows["passwords"]==$password){ return true;} else {return false;}
		}
	}
	function checkString($s){
		for($i=0;$i<strlen($s);$i++){
			if($s[$i]==";") {
				return false;
			}
		}
		return true;
	}
?>