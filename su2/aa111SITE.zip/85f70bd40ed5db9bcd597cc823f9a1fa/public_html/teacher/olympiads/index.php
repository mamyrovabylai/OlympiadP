<?php
echo "<script type=\"text/javascript\">window.location=('http://z70728st.beget.tech/teacher')</script>";
?>