<!DOCTYPE html>
<html>
<head>
<style>
input{
	height:30px;
}
.dt{
	border:1px solid grey;
	border-right:0px;
	padding-left: 0.5%;
	border-top-left-radius:5px;
	border-bottom-left-radius:6px;
}
.tm{
	border:1px solid grey;
	padding-left: 0.5%;
	border-top-right-radius:6px;
	border-bottom-right-radius:6px;
}
#description{
	border:1px solid grey;
	padding-top: 0.5%;
	padding-left: 0.5%;
	border-top-right-radius:6px;
	border-bottom-right-radius:6px;
	border-top-left-radius:5px;
	border-bottom-left-radius:6px;
}
#MC, #SC, #SA{
	width: 100px;
	height: 100px;
	-moz-border-radius: 50px;
	-webkit-border-radius: 50px;
	border-radius: 50px;
}
.MC{
	color: #d7263d;
}
.SC{
	color: #f46036;	
}
.SA{
	color: #5386e4;	
}
#SA{
	border: 2.5px solid #5386e4;
	position: fixed;
	bottom:17%;
	left:22%;
}

#MC{
	border: 2.5px solid #d7263d;
	position: fixed;
	bottom:53%;
	left:22%;
}
#SC{
	border: 2.5px solid #f46036;
	position: fixed;
	bottom:35%;
	left:22%;
}
.MC, .SC, .SA{
	font-size: 21px;
}
.point {
	width:40px;
	border-top-left-radius:0px;
	border-bottom-left-radius:0px;
	border-top-right-radius:6px;
	border-bottom-right-radius:6px;
	padding-left:1%;
	border:1px solid grey;
	border-left:0px;
}

input[type="text"]:not(.point, .OlympName){
	width:23%;
	padding-left:1%;
	border-top-left-radius:6px;
	border-bottom-left-radius:6px;
	border:1px solid grey;
}
input[class="OlympName"]{
	width:23%;
	padding-left:1%;
	border-radius:6px;
	border:1px solid #7f807f;
}
input[type="button"]{
	width:30px;
	background-color:#FFF;
	border:1px solid grey;
	border-left:0px;
	color:grey;
	
}
input[type="checkbox"]{
	height:15px;
	width:15px;
	background:#FFF;
	
}
input[type="radio"]{
	height:15px;
	width:15px;
	background:#FFF;
	
}
.MC,.SC,.SA{
	margin-right:4%;
}
 
</style>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
<script type="text/javascript">
var mcarr = new Array();
var MCCLicked = 0;
var scarr = new Array();
var SCCLicked = 0;
var saarr = new Array();
var SACLicked = 0;
	$(document).ready(function(){

		$(document).on("click", ".MC", function(){
			$('<p id="mcid" class="mcclass"><input type="text" required name="mc" placeholder="MC question"></input><input name="mcadd" class="mcadd" type="button" id="mcaddid" value="+"></input><input class="mcremove" name="mcremove" type="button" id="mcremoveid" value="x"></input><input type="text" required name="n" class="point" value="1" title="Количество баллов за это задание"></input></p>').insertBefore($(".AnsHere"));

			MCCLicked++;
			$('p[id="mcid"]').attr("id","mcid" + MCCLicked);
			$('p[class="mcclass"]').attr("class","mcclass" + MCCLicked);
			$('input[id="mcremoveid"]').attr("id","mcremoveid" + MCCLicked);
			$('input[id="mcaddid"]').attr("id","mcaddid" + MCCLicked);
			$('input[name="mc"]').attr("name","mc" + MCCLicked);
			$('input[name="mcadd"]').attr("name","mcadd" + MCCLicked);
			$('input[name="mcremove"]').attr("name","mcremove" + MCCLicked);
			$('input[name="n"]').attr("name","n" + MCCLicked);
			var m = MCCLicked;
			mcarr[m]=0;

		});

		 $(document).on("click", "input[class='mcremove']", function(){
		 	m = Number(event.target.id.substring(10)); 
			$('.' +"mcclass" + m).remove();
		 });

		$(document).on("click", "input[class='mcadd']", function(){

			m = Number(event.target.id.substring(7));
			mcarr[m]++;
			
			$('<p id="mcanswerid"><input type="checkbox" name="mct"></input><input type="text" required name="mcs" placeholder="answer"></input><input class="mcar" name="mcar" type="button" id="mcarid" value="x" class="point"></input></p>').appendTo($("#mcid" + m)); 

			$('p[id="mcanswerid"]').attr("id","mc" + m + "answer" + mcarr[m]);
			$('p[class="mcclass"]').attr("class","mcclass" + m);
			$('input[id="mcanswerid"]').attr("id","mcremoveid" + mcarr[m]);
			$('input[name="mct"]').attr("name","amc" + m + "mct" + mcarr[m]);
			$('input[name="mcs"]').attr("name","bmc" + m + "mcs" + mcarr[m]);
			$('input[id="mcarid"]').attr("id","mc" + m + "mcarid" + mcarr[m]);
			$('input[name="mcar"]').attr("name","mc" + m + "mcar" + mcarr[m]);	
		});

		$(document).on("click", "input[class='mcar']", function(){
		mcarr[m] = Number(event.target.id.substring(9));
		$('#' +"mc" + m + "answer" + mcarr[m]).remove();
		});

		$(document).on("click", ".SC", function(){
			$('<p id="scid" class="scclass"><input type="text" required name="sc" placeholder="SC question"></input><input name="scadd" class="scadd" type="button" id="scaddid" value="+"></input><input name="scremove" class="scremove" type="button" id="scremoveid" value="x"></input><input type="text" required name="p" class="point" value="1" title="Количество баллов за это задание"></input></p>').insertBefore($(".AnsHere"));

			SCCLicked++;
			$('p[id="scid"]').attr("id","scid" + SCCLicked);
			$('p[class="scclass"]').attr("class","scclass" + SCCLicked);
			$('input[id="scremoveid"]').attr("id","scremoveid" + SCCLicked);
			$('input[name="scremove"]').attr("name","scremove" + SCCLicked);
			$('input[id="scaddid"]').attr("id","scaddid" + SCCLicked);
			$('input[name="sc"]').attr("name","sc" + SCCLicked);
			$('input[name="scadd"]').attr("name","scadd" + SCCLicked);
			$('input[name="p"]').attr("name","p" + SCCLicked);
			var s = SCCLicked;
			scarr[s]=0

		});

		$(document).on("click", "input[class='scremove']", function(){
			s = Number(event.target.id.substring(10)); 
			$('.' +"scclass" + s).remove();
		});

		$(document).on("click", "input[class='scadd']", function(){

			s = Number(event.target.id.substring(7));
			scarr[s]++;

			$('<p id="scanswerid"><input type="radio" name="sct"></input><input type="text" required name="scs" placeholder="answer"></input><input class="scar" name="scar" type="button" id="scarid" value="x"></input></p>').appendTo($("#scid" + s)); 

			$('p[id="scanswerid"]').attr("id","sc" + s + "answer" + scarr[s]);
			$('p[class="scclass"]').attr("class","scclass" + s);
			$('input[id="scanswerid"]').attr("id","scremoveid" + scarr[s]);
			$('input[name="sct"]').attr("name","tsc" + s + "sct" + s);
			$('input[name="scs"]').attr("name","xsc" + s + "scs" + scarr[s]);
			$('input[id="scarid"]').attr("id","sc" + s + "scarid" + scarr[s]);
			$('input[name="scar"]').attr("name","sc" + s + "scar" + scarr[s]);			
		});

		$(document).on("click", "input[class='scar']", function(){
		scarr[s] = Number(event.target.id.substring(9));
		$('#' +"sc" + s + "answer" + scarr[s]).remove();
		});		

		$(document).on("click", ".SA", function(){
			$('<p id="said" class="saclass"><input type="text" required name="sa" placeholder="SA question"></input><input name="saadd" class="saadd" type="button" id="saaddid" value="+"><input name="saremove" class="saremove" type="button" id="saremoveid" value="x"></input><input type="text" required name="d" class="point" value="1" title="Количество баллов за это задание"></input></p>').insertBefore($(".AnsHere"));
			SACLicked++;
			$('p[id="said"]').attr("id","said" + SACLicked);
			$('p[class="saclass"]').attr("class","saclass" + SACLicked);
			$('input[id="saremoveid"]').attr("id","saremoveid" + SACLicked);
			$('input[name="saremove"]').attr("name","saremove" + SACLicked);
			$('input[id="saaddid"]').attr("id","saaddid" + SACLicked);
			$('input[name="sa"]').attr("name","sa" + SACLicked);
			$('input[name="saadd"]').attr("name","saadd" + SACLicked);
			$('input[name="d"]').attr("name","d" + SACLicked);
			var a = SACLicked;
			saarr[a]=0

		});

		$(document).on("click", "input[class='saremove']", function(){
			a = Number(event.target.id.substring(10));
			$('.' +"saclass" + a).remove();
		});

		$(document).on("click", "input[class='saadd']", function(){

			a = Number(event.target.id.substring(7));
			saarr[a]++;

			$('<p id="saanswerid"><input type="text" required name="sas" placeholder="answer"></input><input class="saar" name="saar" type="button" id="saarid" value="x"></input></p>').appendTo($("#said" + a)); 

			$('p[id="saanswerid"]').attr("id","sa" + a + "answer" + saarr[a]);
			$('p[class="scclass"]').attr("class","saclass" + a);
			$('input[id="saanswerid"]').attr("id","saremoveid" + saarr[a]);
			$('input[name="sas"]').attr("name","csa" + a + "sas" + saarr[a]);
			$('input[id="saarid"]').attr("id","sa" + a + "saarid" + saarr[a]);
			$('input[name="saar"]').attr("name","sa" + a + "saar" + saarr[a]);			
		});

		$(document).on("click", "input[class='saar']", function(){
		saarr[a] = Number(event.target.id.substring(9));
		$('#' +"sa" + a + "answer" + saarr[a]).remove();
		});

	});
</script>
</head>
<body>
<center>
	
<?php
if($_GET["q"]=="1"){
		echo "<i style=\"color:#c80000;\">Запрещаются  знаки \" ; \" !</i>";
	}
?>
<form method="post" action="olympiads/createOlympiad.php">
<div></br><input type="text" name="kameOfOlympiad" class="OlympName" placeholder="Введите имя олимпиады" required></input>
	<?php
	$now=date("Y-m-d");
	$now2=date("G:i");
	$now=strtotime($now);
	$now+=86400;
	$now=date("Y-m-d",$now);
	echo '<br/><br/>Начало: <input type="date" name="kach_date" class="dt" value="'.$now.'" min="'.$now.'" />' ;
	echo '<input type="time" class="tm" name="kach_time" value="'.$now2.'" min="'.$now2.'" />';
	
	echo "<br/>";
	$now2=strtotime($now2);
	$now2+=3600;
	$now2=date("G:i",$now2);
	echo '<br/>Конец: <input type="date" name="end_date" class="dt" value="'.$now.'" min="'.$now.'"  />' ;
	echo '<input type="time" name="end_time" value="'.$now2.'"  class="tm" min="'.$now2.'" /><br/><br/>';
	?>
	<textarea id="description" placeholder="Введите описание" name="kescription" cols="50" rows="5" required></textarea><br/><br/><br/>
	<div class="choice">
		<div id="MC"><a href="#" class="MC" onclick="return false"></br>Multiple Choice</a></div>
		<div id="SC"><a href="#" class="SC" onclick="return false"></br>Single Choice</a></div>
		<div id="SA"><a href="#" class="SA" onclick="return false"></br>Short Answer</a></div>

	</div>
</div>
	<div id="answers">
		<a href="#" class="AnsHere"></a>
		</div>
	<input type="submit" name="clickCreate" value="Создать олимпиаду"/>
</form>
</center>
</body>
</html>