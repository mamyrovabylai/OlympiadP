<?php
session_start();
$login=$_SESSION["teacherLogin"];
include("functions.php");
$keys=array();
$values=array();
$count=0;
foreach($_POST as $key => $value){
    if(!checkString($value)) { echo '<script type="text/javascript"> window.location=\'http://z70728st.beget.tech/teacher/index.php?a=3&q=1\'</script>'; exit(); }
	$keys[$count]=$key;
	$values[$count]=$value;
	$count++;
}
$mysqli=connect();
$name=$_POST["kameOfOlympiad"];
$time_start=$_POST["kach_date"]." ".$_POST["kach_time"];
$time_end=$_POST["end_date"]." ".$_POST["end_time"];
$description=$_POST["kescription"];
$q="SELECT `name`,`subject` FROM `teacherusers` WHERE `login`='$login';";
		$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$namet=$rows["name"];
		$subject=$rows["subject"];
		
$q="INSERT INTO `olympiads` (`name`,`subject`,`teacher`,`time_start`,`time_end`,`description`) VALUES ('$name','$subject','$namet','$time_start','$time_end','$description');";
$result=$mysqli->query($q);

$q="SELECT `id` FROM `olympiads` WHERE `name`='$name';";
$result=$mysqli->query($q);
		$rows=$result->fetch_assoc();
		$id=$rows["id"];

$q="CREATE TABLE olympiad$id(
	`id` int(11) NOT NULL AUTO_INCREMENT,
	`type` varchar(20) NOT NULL,
	`question` text NOT NULL,
	`possible_answers` text NOT NULL,
	`right_answers` text NOT NULL,
	`identi` varchar(70) NOT NULL,
	`point` int(11) NOT NULL,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;";
$result=$mysqli->query($q);

echo "<br/>";
//initial data's setting
for($i=0;$i<$count;$i++) {
	$string=$keys[$i];
	if(($string[0]=="m") && ($string[1]=="c")){
		//insert into
		$identi=stristr($keys[$i],$string[2]);
		$question=$values[$i];
		$q="INSERT INTO `olympiad$id` (`question`,`type`,`identi`)VALUES('$question','mc','$identi');";
		$result=$mysqli->query($q);
		
	} else if(($string[0]=="s") && ($string[1]=="c")) {
		$identi=stristr($keys[$i],$string[2]);
		$question=$values[$i];
		$q="INSERT INTO `olympiad$id` (`question`,`type`,`identi`)VALUES('$question','sc','$identi');";
		$result=$mysqli->query($q);
		
	} else if(($string[0]=="s") && ($string[1]=="a")){
		$identi=stristr($keys[$i],$string[2]);
		$question=$values[$i];
		$q="INSERT INTO `olympiad$id` (`question`,`type`,`identi`)VALUES('$question','sa','$identi');";
		$result=$mysqli->query($q);
		
		
	}
}
//right answers set
$obw=0;
for($i=0;$i<$count;$i++) {
		
		$str=$keys[$i];
		if($str[0]=="a") {
			$identi=stristr($str,$str[3]);
			$identi=(int)$identi;
			$type="mc";
					$q="SELECT `right_answers` FROM `olympiad$id` WHERE `identi`='$identi' AND `type`='$type';";
					$result=$mysqli->query($q);
					$rows=$result->fetch_assoc();
					$ransw=$rows["right_answers"];
					$ranswdb=$ransw.$values[$i+1].";";
					$q="UPDATE `olympiad$id` SET `right_answers`='$ranswdb' WHERE `identi`='$identi' AND `type`='$type';";
					$result=$mysqli->query($q);
			
			
		} else if ($str[0]=="t") {
			$identi=stristr($str,$str[3]);
			$identi=(int)$identi;
			$type="sc";
			$ranswdb=$values[$i+1];
			$q="UPDATE `olympiad$id` SET `right_answers`='$ranswdb' WHERE `identi`='$identi' AND `type`='$type';";
			$result=$mysqli->query($q);
			
		} else if ($str[0]=="c") {
			$identi=stristr($str,$str[3]);
			$identi=(int)$identi;
			$type="sa";
			$q="SELECT `right_answers` FROM `olympiad$id` WHERE `identi`='$identi' AND `type`='$type';";
			$result=$mysqli->query($q);
			$rows=$result->fetch_assoc();
			$ransw=$rows["right_answers"];
			$ranswdb=$ransw.$values[$i].";";
			$q="UPDATE `olympiad$id` SET `right_answers`='$ranswdb' WHERE `identi`='$identi' AND `type`='$type';";
			$result=$mysqli->query($q);
			
			
		} else if($str[0]=="n"){
			$value=(int)$values[$i];
			$type="mc";
			$identi=stristr($str,$str[1]);
			$obw=$obw+$value;
			$q="UPDATE `olympiad$id` SET `point`='$value' WHERE `identi`='$identi' AND `type`='$type';";
			$result=$mysqli->query($q);
		} else if($str[0]=="p"){
			$value=(int)$values[$i];
			$type="sc";
			$identi=stristr($str,$str[1]);
			$obw=$obw+$value;
			$q="UPDATE `olympiad$id` SET `point`='$value' WHERE `identi`='$identi' AND `type`='$type';";
			$result=$mysqli->query($q);
		} else if($str[0]=="d"){
			$value=(int)$values[$i];
			
			$type="sa";
			$identi=stristr($str,$str[1]);
			$obw=$obw+$value;
			$q="UPDATE `olympiad$id` SET `point`='$value' WHERE `identi`='$identi' AND `type`='$type';";
			$result=$mysqli->query($q);
		}
		
}
//possible answers set

for($i=0;$i<$count;$i++){
			$str=$keys[$i];
			if($str[0]=="b"){
			$identi=stristr($str,$str[3]);
			$identi=(int)$identi;
			$type="mc";
				$q="SELECT `possible_answers` FROM `olympiad$id` WHERE `identi`='$identi' AND `type`='$type';";
				$result=$mysqli->query($q);
				$rows=$result->fetch_assoc();
				$pansw=$rows["possible_answers"];
				$panswdb=$pansw.$values[$i].";";
				$q="UPDATE `olympiad$id` SET `possible_answers`='$panswdb' WHERE `identi`='$identi' AND `type`='$type';";
				$result=$mysqli->query($q);
			} else if ($str[0]=="x") {
			$identi=stristr($str,$str[3]);
			$identi=(int)$identi;
			$type="sc";
				$q="SELECT `possible_answers` FROM `olympiad$id` WHERE `identi`='$identi' AND `type`='$type';";
				$result=$mysqli->query($q);
				$rows=$result->fetch_assoc();
				$pansw=$rows["possible_answers"];
				$panswdb=$pansw.$values[$i].";";
				$q="UPDATE `olympiad$id` SET `possible_answers`='$panswdb' WHERE `identi`='$identi' AND `type`='$type';";
				$result=$mysqli->query($q);
			}
			
}
// добавление олимпиады в мой профиль
$q="SELECT `olympiads` FROM `teacherusers` WHERE `login`='$login'";
$result=$mysqli->query($q);
$rows = $result->fetch_assoc();
$olmp=$rows["olympiads"];
$olmpbd=$olmp.$id.";";
$q="UPDATE `teacherusers` SET `olympiads`='$olmpbd' WHERE `login`='$login'";
$result=$mysqli->query($q);
$q="UPDATE `olympiads` SET `total_band`=$obw WHERE `id`='$id'";
$result=$mysqli->query($q);
 echo '<script type="text/javascript"> window.location="http://z70728st.beget.tech/teacher"; </script>';
 exit();
?>