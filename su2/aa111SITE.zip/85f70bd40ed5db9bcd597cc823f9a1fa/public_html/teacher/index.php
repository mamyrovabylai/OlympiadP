<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["teacherLogin"]) || !isset($_SESSION["teacherPassword"]) ){
	header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
} else if(!loginT($_SESSION["teacherLogin"],$_SESSION["teacherPassword"])){
	 header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["teacherLogin"];
	$password=$_SESSION["teacherPassword"]; 
}

?>
<html>
<head>
<title>Главная</title>
<meta charset="utf-8"/>
<link rel="stylesheet" href="css/main.css" type="text/css"/>
</head>
<body>
		<?php
		include("header.html");
		include("underhead.php");
			
			include("olympUnderHead.html");
			echo "<div class=\"main\">";
			if($_GET["a"]=="1"){
				include("olympiads/old.php");
			}else if($_GET["a"]=="3") {
				include("olympiads/create.php");
			} else {
				include("olympiads/futureOlympiads.php");
			}
		echo "</div>";	

?>
</body>
<?php include("footer.html"); ?>
<div class="bottom">

</div>
		
</body>
</html>