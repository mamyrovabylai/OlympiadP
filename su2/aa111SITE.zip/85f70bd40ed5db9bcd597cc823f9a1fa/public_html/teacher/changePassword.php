<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["teacherLogin"]) || !isset($_SESSION["teacherPassword"]) ){
	header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
} else if(!loginT($_SESSION["teacherLogin"],$_SESSION["teacherPassword"])){
	 header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["teacherLogin"];
	$password=$_SESSION["teacherPassword"]; 
}
if(isset($_POST["changePassword"])){
	if(isset($_POST["password"])&&isset($_POST["passwordNew"])&&isset($_POST["passwordAgain"])){
		$pass=$_POST["password"];
		$newp=$_POST["passwordNew"];
		$againp=$_POST["passwordAgain"];
		if(loginT($login,md5($pass))){
			if($newp==$againp){
				$newp=md5($newp);
				$mysqli=connect();
				$q="UPDATE `teacherusers` SET `passwords`='$newp' WHERE `login`='$login';";
				$result=$mysqli->query($q);
				header('Location: http://z70728st.beget.tech/teacherLogin.php');
				exit();
			} else { 
					header('Location: http://z70728st.beget.tech/teacher/profile.php?q=1');
					exit();
			}
		}else {header('Location: http://z70728st.beget.tech/teacher/profile.php?q=2');
					exit();}
	} else {	header('Location: http://z70728st.beget.tech/teacher/profile.php?q=3');
					exit();}
} else { header('Location: http://z70728st.beget.tech/teacher/profile.php');
					exit();}
?>