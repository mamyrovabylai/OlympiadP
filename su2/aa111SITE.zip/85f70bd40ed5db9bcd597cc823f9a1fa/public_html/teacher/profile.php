<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["teacherLogin"]) || !isset($_SESSION["teacherPassword"]) ){
	header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
} else if(!loginT($_SESSION["teacherLogin"],$_SESSION["teacherPassword"])){
	 header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["teacherLogin"];
	$password=$_SESSION["teacherPassword"]; 
}

?>
<html>
<head>
	<title> Profile</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/profile.css" type="text/css"/>
</head>

<body>
		<?php
		include("header.html");
		include("underhead.php");
		require_once("functions.php");
		echo "<div class=\"main1\">";
		$mysqli=connect();
		if ($mysqli){
			$q="SELECT `id`,`login`,`name`,`email`,`school`,`photo`,`olympiads`,`subject` FROM `teacherusers` WHERE `login`='".$_SESSION["teacherLogin"]."';";
			$result=$mysqli->query($q);
			$rows=$result->fetch_assoc();
			do{
				$photo=$rows["photo"];
				echo "<div class=\"main\">";
				echo "<div class=\"image\"><img src=\"$photo\" /></div><br/>";
				echo ' <div class="labels">
					<div id="name"> Имя :</div>
					<br/>
					<div> Логин : </div>
					<br/>
					<div> E-mail : </div>
					<br/>
					<div> Школа : </div>
					<br/>
					<div> Урок : </div>
					<br/>
					
					
				</div>
				';
				echo "<div class=\"labelinputs\"> <input  type=\"text\" value=\"".$rows["name"]."\" name=\"name\" disabled > <br/>";
				echo "<br/><input  type=\"text\" value=\"".$rows["login"]."\" name=\"login\"  disabled> <br/>";
				echo "<br/>  <input type=\"email\" value=\"".$rows["email"]."\" name=\"email\" disabled >  <br/>";
				echo "<br/>  <input type=\"text\" value=\"".$rows["school"]."\" name=\"school\" disabled  > <br/>";
				echo "<br/>  <input type=\"text\" value=\"".$rows["subject"]."\" name=\"school\" disabled >  <br/>
						
						</div><br/>";
						
						
						echo "<span class=\"blue\">Поменять пароль</span>";
				echo "<div class=\"password\"> <form action=\"changePassword.php\" method=\"POST\" ><input required type=\"password\"  name=\"password\" placeholder=\"Введите пароль\" > <br/>";
				echo "<br/><input required type=\"password\"  name=\"passwordNew\" placeholder=\"Введите новый пароль снова\"> <br/>";
				echo "<br/>  <input required type=\"password\"  name=\"passwordAgain\" placeholder=\"Введите новый пароль снова\"> <br/>
						
						<br/> <input id=\"button\" type=\"submit\" name=\"changePassword\" value=\"Поменять пароль!\"  />  </form></div><br/>";
						if(isset($_GET["q"])){
							switch ($_GET["q"]){
								case "1":
									echo "<span class\"red\">Пароли не совпадают<!/span>";
									break;
								case "2":
									echo "<span class\"red\">Текущий пароль неверный!</span>";
									break;
								case "3":
									echo "<span class\"red\">Не утсановлены пароли для ввода!</span>";
									break;
							}
						}
						
						
						
						
				
				
				
			
			
			} while ($rows=$result->fetch_assoc());
			
		}
		echo "</div>";	
		echo "<a href=\"myRate.php\" id=\"ratelink\"> Данные о олимпиадах ,которые я создал</a>";
		include("footer.html");
	    
		?>
</body>
<div class="bottom">

</div>

</html>