<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["teacherLogin"]) || !isset($_SESSION["teacherPassword"]) ){
	header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
} else if(!loginT($_SESSION["teacherLogin"],$_SESSION["teacherPassword"])){
	 header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["teacherLogin"];
	$password=$_SESSION["teacherPassword"]; 
}

?>
<html>

<head>
	<title> Rating</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/inform.css" type="text/css"/>
</head>

<body>
<?php include("header.html"); ?>
<div class="main">
		<?php
		$logins=trim(stripslashes(htmlspecialchars($_GET["q"])));
		$mysqli=connect();
		if ($mysqli){
			$q="SELECT `name`,`school`,`grade`,`email`,`photo` FROM `studentusers` WHERE `login`='$logins';";
			$result=$mysqli->query($q);
			
			
			if($result->num_rows>0){
				$q2="SELECT `your_olympiads`,`score` FROM `studentolympiads` WHERE `login`='$logins';";
				$result2=$mysqli->query($q2);
				$rows=$result->fetch_assoc();
			$rows2=$result2->fetch_assoc();
			$photo=$rows["photo"];
			echo '<div class="main1">';
				echo "<div class=\"image\"><img src=\"$photo\" /></div>".$rows["name"]."<br/><br/>";
				echo "Школа : ".$rows["school"]."<br/><br/>Grade : ".$rows["grade"]."<br/><br/>";
				echo "Email : ".$rows["email"]."<br/><br/>";
				echo "Общий балл : ".$rows2["score"]."<br/>";
			echo '</div>';
			echo '<div class="main2">';
			
			
		echo "<a href=\"studentRateOlymp.php?q=$logins\" id=\"ratelink\"> Данные о олимпиадах , в которых он(-а) участвовал(-а)</a>";		
			
			
			
					echo "</div>";
				
			} else {echo "Таких учеников нет!";}	
		}
		?>
		<button style="float:right;margin-top:10%;width:100px;" id="link"><a  href="rating.php" >Назад</a></button><br/>
</div><br/>
<?php
include("footer.html");
?>
</body>

</html>