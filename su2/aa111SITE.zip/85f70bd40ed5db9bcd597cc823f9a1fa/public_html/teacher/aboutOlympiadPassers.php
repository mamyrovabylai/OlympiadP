<?php
session_start();
header('Content-Type: text/html; charset= utf-8');
require_once("functions.php");
	
if(!isset($_SESSION["teacherLogin"]) || !isset($_SESSION["teacherPassword"]) ){
	header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
} else if(!loginT($_SESSION["teacherLogin"],$_SESSION["teacherPassword"])){
	 header('Location: http://z70728st.beget.tech/teacherLogin.php?q=0');
	exit();
 } else{$login=$_SESSION["teacherLogin"];
	$password=$_SESSION["teacherPassword"]; 
}

?>
<html>

<head>
	<title> Результаты</title>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/inform.css" type="text/css"/>
</head>
<style>
table{
border-collapse:collapse;
margin-left:3%;	
}
td{
	color:#fff;
	padding:5px;
}
table,tr,td{
	border:1px solid silver;
}
</style>

<body>
<?php include("header.html"); ?>
<div class="main">
<?php
if(isset($_GET["q"])){
	$now=date("Y-m-d H:i:s");
	$id=$_GET["q"];
	$mysqli=connect();
	$q="SELECT `name`,`participants`,`bands`,`time_end`,`total_band` FROM `olympiads` WHERE `id`=$id;";
	$result=$mysqli->query($q);
	if($result->num_rows!=0){
		$rows=$result->fetch_assoc();
		if($now>$rows["time_end"]){
		$name=$rows["name"];
		echo "Олимпиада - ".$name."<br/><br/>";
		$participants=array(); $participants=explode(";",$rows["participants"]);
		$bands=array(); $bands=explode(";",$rows["bands"]);
		$count=count($bands)-1;
		$total_band=$rows["total_band"];
		for($i=0;$i<$count-1;$i++){
			for($j=$i+1;$j<$count;$j++){
				if($bands[$i]<$bands[$j]){
					$buff=$bands[$i];
					$bands[$i]=$bands[$j];
					$bands[$j]=$buff;
					
					$buff=$participants[$i];
					$participants[$i]=$participants[$j];
					$participants[$j]=$buff;
				}
			}
		}
		echo "<table cols=\"2\" width=\"90%\">";
		echo "<tr>
		<td> Имя ученика </td>
		<td> Количество баллов из $total_band</td>
		<tr/>";
		
		for($i=0;$i<$count;$i++){
			$q="SELECT `name` FROM `studentusers` WHERE `login`='$participants[$i]'";
			$result=$mysqli->query($q);
			$rows=$result->fetch_assoc();
			$participant=$rows["name"];
			echo "<tr>";
			echo "<td> <a href=\"studentRate.php?q=".$participants[$i]."\" style=\"color:#fff;text-decoration:underline;\">".$participant."</a></td>";
			echo "<td>$bands[$i] </td>";
			echo "</tr>";
			
		}
		echo "</table>";
	} else { echo "Данная олимпиада не закончена !";}
	} else { echo "Данной олимпиады не существует 	!";
	}
} else { echo "<script type=\"text/javascript\"> window.location='http://z70728st.beget.tech/student'</script>";
	exit();}
		echo '<button style="float:right;margin-top:3%;" id="link"><a  href="aboutOlympiad.php?q='.$id.'" >Назад</a></button><br/>';
?>

</div><br/>
<?php
include("footer.html");
?>